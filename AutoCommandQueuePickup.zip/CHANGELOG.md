### 1.0.0 - Initial release

### 1.0.1 - added dll file

### 1.0.2 - modified how command cube is destroyed on drop